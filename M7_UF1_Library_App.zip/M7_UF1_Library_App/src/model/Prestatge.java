
package model;

/**
 *
 * @author arnau
 */
public class Prestatge {
    
    private int idPrestatge;
    private String nom;

    public Prestatge() {
    }



    public int getIdPrestatge() {
        return idPrestatge;
    }

    public void setIdPrestatge(int idPrestatge) {
        this.idPrestatge = idPrestatge;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }
    
    
    
}
